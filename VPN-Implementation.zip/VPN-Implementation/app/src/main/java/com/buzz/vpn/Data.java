package com.buzz.vpn;

public class Data {
    static String FileUsername;
    static String FilePassword;


    static boolean isAppDetails = false, isConnectionDetails = false;
    static String PREF_USAGE = "daily_usage";
    public static String StringCountDown;
    public static long LongDataUsage;


}
